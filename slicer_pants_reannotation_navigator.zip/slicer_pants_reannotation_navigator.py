"""
PanTS tumor-positive reannotation navigator for 3D Slicer.

Run inside Slicer Python interactor:
    exec(open("/path/to/analysis/slicer_pants_reannotation_navigator.py").read())

Workflow:
1. Select the PanTS dataset root (containing metadata.xlsx, ImageTr/ImageTe, LabelTr/LabelTe).
2. Script reads metadata.xlsx and keeps only tumor-positive cases.
3. For each case, it loads:
   - CT volume
   - A segmentation node containing:
     - pancreas segment (from pancreas.nii.gz if available)
     - pancreatic_duct segment (from pancreatic_duct.nii.gz if available)
     - common_bile_duct segment (from common_bile_duct.nii.gz if available)
     - pancreatic_lesion segment (from pancreatic_lesion.nii.gz if available)
4. Annotate in Slicer.
5. Click "Save + Next" (or "Next (No Save)") to move to the next case.

Saved outputs (default):
    <dataset_root>/ReannotatedLabel/<case_id>/segmentations/pancreas.nii.gz
    <dataset_root>/ReannotatedLabel/<case_id>/segmentations/pancreatic_duct.nii.gz
    <dataset_root>/ReannotatedLabel/<case_id>/segmentations/common_bile_duct.nii.gz
    <dataset_root>/ReannotatedLabel/<case_id>/segmentations/pancreatic_lesion.nii.gz
    <dataset_root>/ReannotatedLabel/<case_id>/reannotation.seg.nrrd
"""

# Version history:
# 2026-03-01: Most features implemented.
# 2026-03-02: Added skip reviewed cases functionality.
# 2026-03-08: Added metadata export reminder and export button. Import ducts.
# 2026-03-09: Added specifc colors for Joost

from __future__ import annotations

import json
import traceback
import zipfile
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter

import qt  # type: ignore
import slicer  # type: ignore
import vtk  # type: ignore

CT_ABDOMEN_WINDOW = 350.0
CT_ABDOMEN_LEVEL = 40.0
METADATA_COL_MISMATCH_PREDICTED_PHASE = "mismatch_predicted_phase"

METADATA_COL_IMAGE_QUALITY_BAD = "Reannot Image Quality Bad"
METADATA_COL_PANCREAS_QUALITY_BAD = "Reannot Pancreas Quality Bad"
METADATA_COL_PANCREAS_ADJUSTED = "Reannot Pancreas Adjusted"
METADATA_COL_PANCREAS_ADJUST_LATER = "Reannot Pancreas Adjust Later"
METADATA_COL_LESION_TYPE_TUMOR = "Reannot Lesion Type Tumor"
METADATA_COL_LESION_TYPE_CYSTE = "Reannot Lesion Type Cyste"
METADATA_COL_LESION_TYPE_TUMOR_CYSTE = "Reannot Lesion Type Tumor + Cyste"
METADATA_COL_LESION_TYPE_MULTIPLE_TUMORS = "Reannot Lesion Type Multiple Tumors"
METADATA_COL_LESION_QUALITY_BAD = "Reannot Lesion Quality Bad"
METADATA_COL_LESION_ADJUSTED = "Reannot Lesion Adjusted"
METADATA_COL_LESION_IGNORED = "Reannot Lesion Ignored"
METADATA_COL_LESION_ADJUST_LATER = "Reannot Lesion Adjust Later"
METADATA_COL_LESION_NOT_VISIBLE = "Reannot Lesion Not Visible"
METADATA_COL_ATYPICAL_TUMOR = "Reannot Atypical Tumor"
METADATA_COL_ATYPICAL_TUMOR_NET = "Reannot Atypical Tumor NET"
METADATA_COL_ATYPICAL_TUMOR_IPMN = "Reannot Atypical Tumor IPMN"
METADATA_COL_ATYPICAL_TUMOR_OTHER = "Reannot Atypical Tumor Other"
METADATA_COL_ATYPICAL_TUMOR_OTHER_NAME = "Reannot Atypical Tumor Other Name"
METADATA_COL_COMMENTS = "Reannot Comments"

REANNOTATION_METADATA_COLUMNS = [
    ("image_quality_bad", METADATA_COL_IMAGE_QUALITY_BAD),
    ("pancreas_quality_bad", METADATA_COL_PANCREAS_QUALITY_BAD),
    ("pancreas_adjusted", METADATA_COL_PANCREAS_ADJUSTED),
    ("pancreas_adjust_later", METADATA_COL_PANCREAS_ADJUST_LATER),
    ("lesion_type_tumor", METADATA_COL_LESION_TYPE_TUMOR),
    ("lesion_type_cyste", METADATA_COL_LESION_TYPE_CYSTE),
    ("lesion_type_tumor_cyste", METADATA_COL_LESION_TYPE_TUMOR_CYSTE),
    ("lesion_type_multiple_tumors", METADATA_COL_LESION_TYPE_MULTIPLE_TUMORS),
    ("lesion_quality_bad", METADATA_COL_LESION_QUALITY_BAD),
    ("lesion_adjusted", METADATA_COL_LESION_ADJUSTED),
    ("lesion_ignored", METADATA_COL_LESION_IGNORED),
    ("lesion_adjust_later", METADATA_COL_LESION_ADJUST_LATER),
    ("lesion_not_visible", METADATA_COL_LESION_NOT_VISIBLE),
    ("atypical_tumor", METADATA_COL_ATYPICAL_TUMOR),
    ("atypical_tumor_net", METADATA_COL_ATYPICAL_TUMOR_NET),
    ("atypical_tumor_ipmn", METADATA_COL_ATYPICAL_TUMOR_IPMN),
    ("atypical_tumor_other", METADATA_COL_ATYPICAL_TUMOR_OTHER),
    ("atypical_tumor_other_name", METADATA_COL_ATYPICAL_TUMOR_OTHER_NAME),
    ("comments", METADATA_COL_COMMENTS),
]

REANNOTATION_TEXT_KEYS = {"atypical_tumor_other_name", "comments"}
REVIEW_COMPLETION_FILENAME = "_review_completed.json"
REVIEW_METADATA_FILENAME = "_review_metadata.json"


def _hex_to_rgb01(hex_color: str):
    hex_value = hex_color.lstrip("#")
    if len(hex_value) != 6:
        raise ValueError(f"Expected 6-digit hex color, got: {hex_color}")
    return tuple(int(hex_value[i : i + 2], 16) / 255.0 for i in range(0, 6, 2))


SEGMENT_COLORS = {
    "pancreas": _hex_to_rgb01("#00C8C8"),
    "pancreatic_duct": _hex_to_rgb01("#7DFF4D"),
    "common_bile_duct": _hex_to_rgb01("#CC4CFF"),
    "pancreatic_lesion": _hex_to_rgb01("#DCF514"),
}


def _truthy_tumor_flag(value):
    if value is None:
        return False
    text = str(value).strip().lower()
    if text in {"", "nan", "none"}:
        return False
    if text in {"1", "true", "yes", "y", "positive", "tumor"}:
        return True
    if text in {"0", "false", "no", "n", "negative"}:
        return False
    try:
        return float(text) != 0.0
    except Exception:
        return False


def _read_tumor_positive_case_ids(metadata_xlsx: Path):
    # Try pandas first.
    try:
        import pandas as pd  # type: ignore

        df = pd.read_excel(str(metadata_xlsx))
        if "PanTS ID" not in df.columns or "tumor?" not in df.columns:
            raise RuntimeError("metadata.xlsx must contain columns 'PanTS ID' and 'tumor?'.")
        ids = []
        for _, row in df.iterrows():
            case_id = str(row["PanTS ID"]).strip()
            if _truthy_tumor_flag(row["tumor?"]) and case_id:
                ids.append(case_id)
        return ids
    except Exception:
        pass

    # Fallback to openpyxl.
    try:
        import openpyxl  # type: ignore

        wb = openpyxl.load_workbook(str(metadata_xlsx), data_only=True, read_only=True)
        ws = wb[wb.sheetnames[0]]
        header = [cell.value for cell in next(ws.iter_rows(min_row=1, max_row=1))]
        if "PanTS ID" not in header or "tumor?" not in header:
            raise RuntimeError("metadata.xlsx must contain columns 'PanTS ID' and 'tumor?'.")
        id_idx = header.index("PanTS ID")
        tumor_idx = header.index("tumor?")
        ids = []
        for row in ws.iter_rows(min_row=2, values_only=True):
            case_id = "" if row[id_idx] is None else str(row[id_idx]).strip()
            tumor_val = row[tumor_idx]
            if _truthy_tumor_flag(tumor_val) and case_id:
                ids.append(case_id)
        return ids
    except Exception:
        pass

    # Pure-Python fallback (no external dependencies): parse XLSX XML directly.
    try:
        return _read_tumor_positive_case_ids_builtin_xlsx(metadata_xlsx)
    except Exception as exc:
        raise RuntimeError(
            "Could not read metadata.xlsx with pandas, openpyxl, or built-in XLSX parser.\n"
            "If preferred, install openpyxl in Slicer Python:\n"
            "  slicer.util.pip_install('openpyxl')\n"
            f"Reader error: {exc}"
        )


def _xlsx_col_to_index(col_ref: str) -> int:
    value = 0
    for ch in col_ref:
        if "A" <= ch <= "Z":
            value = value * 26 + (ord(ch) - ord("A") + 1)
    return max(0, value - 1)


def _xlsx_cell_ref_to_col(ref: str) -> int:
    letters = "".join(ch for ch in ref if ch.isalpha()).upper()
    return _xlsx_col_to_index(letters)


def _xlsx_read_shared_strings(zf: zipfile.ZipFile):
    if "xl/sharedStrings.xml" not in zf.namelist():
        return []
    root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
    ns = {"x": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
    values = []
    for si in root.findall("x:si", ns):
        # Shared string item can be plain <t> or rich text with multiple <r><t>.
        t = si.find("x:t", ns)
        if t is not None:
            values.append(t.text or "")
            continue
        runs = si.findall(".//x:r/x:t", ns)
        values.append("".join((r.text or "") for r in runs))
    return values


def _xlsx_find_target_sheet(zf: zipfile.ZipFile):
    ns_main = {"x": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
    ns_rel = {"r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships"}

    wb_root = ET.fromstring(zf.read("xl/workbook.xml"))
    rels_root = ET.fromstring(zf.read("xl/_rels/workbook.xml.rels"))

    rel_map = {}
    for rel in rels_root.findall("{http://schemas.openxmlformats.org/package/2006/relationships}Relationship"):
        rel_id = rel.attrib.get("Id")
        target = rel.attrib.get("Target")
        if rel_id and target:
            rel_map[rel_id] = target

    sheets = wb_root.findall("x:sheets/x:sheet", ns_main)
    chosen = None
    for sheet in sheets:
        if (sheet.attrib.get("name") or "").strip() == "PanTS_metadata":
            chosen = sheet
            break
    if chosen is None and sheets:
        chosen = sheets[0]
    if chosen is None:
        raise RuntimeError("No sheets found in metadata.xlsx")

    rel_id = chosen.attrib.get(f"{{{ns_rel['r']}}}id")
    target = rel_map.get(rel_id or "")
    if not target:
        raise RuntimeError("Could not resolve worksheet relationship in metadata.xlsx")

    # Normalize path inside XLSX zip.
    if target.startswith("/"):
        sheet_path = target.lstrip("/")
    elif target.startswith("xl/"):
        sheet_path = target
    else:
        sheet_path = f"xl/{target}"
    return sheet_path


def _read_tumor_positive_case_ids_builtin_xlsx(metadata_xlsx: Path):
    with zipfile.ZipFile(metadata_xlsx, "r") as zf:
        shared_strings = _xlsx_read_shared_strings(zf)
        sheet_path = _xlsx_find_target_sheet(zf)
        if sheet_path not in zf.namelist():
            raise RuntimeError(f"Worksheet XML not found: {sheet_path}")

        root = ET.fromstring(zf.read(sheet_path))
        ns = {"x": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}

        rows = root.findall(".//x:sheetData/x:row", ns)
        if not rows:
            raise RuntimeError("Worksheet has no rows")

        parsed_rows = []
        for row in rows:
            values = {}
            for cell in row.findall("x:c", ns):
                ref = cell.attrib.get("r", "")
                col_idx = _xlsx_cell_ref_to_col(ref)
                cell_type = cell.attrib.get("t", "")
                if cell_type == "inlineStr":
                    t_node = cell.find("x:is/x:t", ns)
                    value = (t_node.text if t_node is not None else "") or ""
                else:
                    v_node = cell.find("x:v", ns)
                    raw = (v_node.text if v_node is not None else "") or ""
                    if cell_type == "s":
                        try:
                            value = shared_strings[int(raw)]
                        except Exception:
                            value = ""
                    else:
                        value = raw
                values[col_idx] = value
            parsed_rows.append(values)

        header_row = parsed_rows[0]
        header_map = {str(v).strip(): idx for idx, v in header_row.items()}
        if "PanTS ID" not in header_map or "tumor?" not in header_map:
            raise RuntimeError("metadata.xlsx must contain columns 'PanTS ID' and 'tumor?'.")

        id_idx = header_map["PanTS ID"]
        tumor_idx = header_map["tumor?"]

        case_ids = []
        for row in parsed_rows[1:]:
            case_id = str(row.get(id_idx, "")).strip()
            tumor_val = row.get(tumor_idx, "")
            if case_id and _truthy_tumor_flag(tumor_val):
                case_ids.append(case_id)
        return case_ids


def _find_case_paths(dataset_root: Path, case_id: str):
    for split in ("Tr", "Te"):
        ct_path = dataset_root / f"Image{split}" / case_id / "ct.nii.gz"
        if ct_path.exists():
            seg_dir = dataset_root / f"Label{split}" / case_id / "segmentations"
            return {
                "case_id": case_id,
                "split": split,
                "ct_path": ct_path,
                "pancreas_path": seg_dir / "pancreas.nii.gz",
                "pancreatic_duct_path": seg_dir / "pancreatic_duct.nii.gz",
                "common_bile_duct_path": seg_dir / "common_bile_duct.nii.gz",
                "lesion_path": seg_dir / "pancreatic_lesion.nii.gz",
                "seg_dir": seg_dir,
            }
    return None


def _apply_ct_abdomen_window(volume_node):
    if volume_node is None:
        return

    display_node = volume_node.GetDisplayNode()
    if display_node is None:
        volume_node.CreateDefaultDisplayNodes()
        display_node = volume_node.GetDisplayNode()
    if display_node is None:
        return

    # Match Slicer's CT-Abdomen window/level preset in slice viewers.
    display_node.AutoWindowLevelOff()
    display_node.SetWindow(CT_ABDOMEN_WINDOW)
    display_node.SetLevel(CT_ABDOMEN_LEVEL)


def _safe_stripped(value):
    if value is None:
        return ""
    return str(value).strip()


def _default_review_metadata_values():
    values = {}
    for key, _ in REANNOTATION_METADATA_COLUMNS:
        values[key] = "" if key in REANNOTATION_TEXT_KEYS else False
    return values


def _normalized_review_metadata_values(values):
    normalized = _default_review_metadata_values()
    if not values:
        return normalized

    for key, _ in REANNOTATION_METADATA_COLUMNS:
        if key in REANNOTATION_TEXT_KEYS:
            normalized[key] = _safe_stripped(values.get(key, ""))
        else:
            normalized[key] = bool(values.get(key, False))
    return normalized


class PanTSReannotationNavigator:
    def __init__(self, dataset_root: Path, output_root: Path):
        self.dataset_root = dataset_root
        self.output_root = output_root

        self.case_records = []
        self.current_index = -1
        self.loaded_node_ids = []
        self.current_case = None
        self.current_volume_node = None
        self.current_seg_node = None
        self.current_segment_ids = {}
        self.metadata_path = self.dataset_root / "metadata.xlsx"

        self.dialog = None
        self.predicted_phase_label = None
        self.case_label = None
        self.status_label = None
        self.metadata_export_reminder_label = None
        self.image_quality_bad_checkbox = None
        self.pancreas_quality_bad_checkbox = None
        self.pancreas_adjusted_radio = None
        self.pancreas_adjust_later_radio = None
        self.pancreas_quality_detail_container = None
        self.pancreas_quality_detail_group = None
        self.lesion_type_tumor_radio = None
        self.lesion_type_cyste_radio = None
        self.lesion_type_tumor_cyste_radio = None
        self.lesion_type_multiple_tumors_radio = None
        self.lesion_type_group = None
        self.lesion_quality_bad_checkbox = None
        self.lesion_adjusted_radio = None
        self.lesion_ignored_radio = None
        self.lesion_adjust_later_radio = None
        self.lesion_not_visible_radio = None
        self.lesion_quality_detail_container = None
        self.lesion_quality_detail_group = None
        self.atypical_tumor_checkbox = None
        self.atypical_tumor_detail_container = None
        self.atypical_tumor_net_radio = None
        self.atypical_tumor_ipmn_radio = None
        self.atypical_tumor_other_radio = None
        self.atypical_tumor_type_group = None
        self.atypical_tumor_other_name_edit = None
        self.comments_text_edit = None
        self.skip_reviewed_checkbox = None
        self.skip_nrrd_save_checkbox = None

    def initialize(self):
        metadata_path = self.metadata_path
        if not metadata_path.exists():
            raise RuntimeError(f"metadata.xlsx not found at: {metadata_path}")

        tumor_case_ids = _read_tumor_positive_case_ids(metadata_path)
        if not tumor_case_ids:
            raise RuntimeError("No tumor-positive cases found in metadata.xlsx.")

        missing = []
        for case_id in tumor_case_ids:
            rec = _find_case_paths(self.dataset_root, case_id)
            if rec is None:
                missing.append(case_id)
            else:
                self.case_records.append(rec)

        if not self.case_records:
            raise RuntimeError("No tumor-positive cases could be resolved to image paths.")

        self.output_root.mkdir(parents=True, exist_ok=True)
        self._build_ui()
        initial_index = self._find_case_index(-1, 1, self._is_skip_reviewed_enabled())
        if initial_index is None:
            self.load_case(0)
            if self._is_skip_reviewed_enabled():
                self._set_status("All cases appear reviewed. Disable 'Skip reviewed cases' to browse all.")
        else:
            self.load_case(initial_index)

        if missing:
            slicer.util.infoDisplay(
                "Some tumor-positive cases were listed in metadata but not found in dataset folders.\n"
                f"Missing count: {len(missing)}\n"
                f"First missing examples: {', '.join(missing[:10])}"
            )

    def _build_ui(self):
        self.dialog = qt.QDialog(slicer.util.mainWindow())
        self.dialog.setWindowTitle("PanTS Reannotation Navigator")
        self.dialog.resize(920, 520)
        layout = qt.QVBoxLayout(self.dialog)

        self.predicted_phase_label = qt.QLabel("")
        self.predicted_phase_label.wordWrap = True
        self.case_label = qt.QLabel("")
        self.case_label.wordWrap = True
        self.status_label = qt.QLabel("")
        self.status_label.wordWrap = True
        self.metadata_export_reminder_label = qt.QLabel("")
        self.metadata_export_reminder_label.wordWrap = True

        layout.addWidget(self.predicted_phase_label)
        layout.addWidget(self.case_label)
        layout.addWidget(self.status_label)
        layout.addWidget(self.metadata_export_reminder_label)

        self.skip_reviewed_checkbox = qt.QCheckBox("Skip reviewed cases during navigation")
        self.skip_reviewed_checkbox.setChecked(True)
        self.skip_reviewed_checkbox.setToolTip(
            "Reviewed means completion marker exists (preferred, even if full .seg.nrrd saving is disabled), "
            "or legacy output files are complete."
        )
        layout.addWidget(self.skip_reviewed_checkbox)

        self.skip_nrrd_save_checkbox = qt.QCheckBox("Skip saving full reannotation.seg.nrrd")
        self.skip_nrrd_save_checkbox.setChecked(False)
        self.skip_nrrd_save_checkbox.setToolTip(
            "When enabled, Save and Save + Next only export the pancreas/lesion NIfTI files and metadata."
        )
        layout.addWidget(self.skip_nrrd_save_checkbox)

        review_group = qt.QGroupBox("Review / Metadata Flags")
        review_layout = qt.QVBoxLayout(review_group)

        self.image_quality_bad_checkbox = qt.QCheckBox("Image Quality Bad")
        review_layout.addWidget(self.image_quality_bad_checkbox)

        pancreas_row = qt.QHBoxLayout()
        self.pancreas_quality_bad_checkbox = qt.QCheckBox("Pancreas Quality Bad")
        self.pancreas_quality_bad_checkbox.toggled.connect(self._on_pancreas_quality_bad_toggled)
        pancreas_row.addWidget(self.pancreas_quality_bad_checkbox)

        self.pancreas_quality_detail_container = qt.QWidget()
        pancreas_detail_layout = qt.QHBoxLayout(self.pancreas_quality_detail_container)
        pancreas_detail_layout.setContentsMargins(0, 0, 0, 0)
        pancreas_detail_layout.addWidget(qt.QLabel("If bad:"))
        self.pancreas_adjusted_radio = qt.QRadioButton("Adjusted")
        self.pancreas_adjust_later_radio = qt.QRadioButton("Adjust later")
        pancreas_detail_layout.addWidget(self.pancreas_adjusted_radio)
        pancreas_detail_layout.addWidget(self.pancreas_adjust_later_radio)
        pancreas_detail_layout.addStretch(1)
        self.pancreas_quality_detail_group = qt.QButtonGroup(self.dialog)
        self.pancreas_quality_detail_group.setExclusive(True)
        self.pancreas_quality_detail_group.addButton(self.pancreas_adjusted_radio)
        self.pancreas_quality_detail_group.addButton(self.pancreas_adjust_later_radio)
        pancreas_row.addWidget(self.pancreas_quality_detail_container, 1)
        review_layout.addLayout(pancreas_row)

        lesion_type_row = qt.QHBoxLayout()
        lesion_type_row.addWidget(qt.QLabel("Lesion Type:"))
        self.lesion_type_tumor_radio = qt.QRadioButton("Tumor")
        self.lesion_type_cyste_radio = qt.QRadioButton("Cyste")
        self.lesion_type_tumor_cyste_radio = qt.QRadioButton("Tumor + Cyste (cyst(s) removed)")
        self.lesion_type_multiple_tumors_radio = qt.QRadioButton("Multiple tumors")
        self.lesion_type_group = qt.QButtonGroup(self.dialog)
        self.lesion_type_group.setExclusive(True)
        self.lesion_type_group.addButton(self.lesion_type_tumor_radio)
        self.lesion_type_group.addButton(self.lesion_type_cyste_radio)
        self.lesion_type_group.addButton(self.lesion_type_tumor_cyste_radio)
        self.lesion_type_group.addButton(self.lesion_type_multiple_tumors_radio)
        lesion_type_row.addWidget(self.lesion_type_tumor_radio)
        lesion_type_row.addWidget(self.lesion_type_cyste_radio)
        lesion_type_row.addWidget(self.lesion_type_tumor_cyste_radio)
        lesion_type_row.addWidget(self.lesion_type_multiple_tumors_radio)
        lesion_type_row.addStretch(1)
        review_layout.addLayout(lesion_type_row)

        lesion_quality_row = qt.QHBoxLayout()
        self.lesion_quality_bad_checkbox = qt.QCheckBox("Lesion Quality Bad")
        self.lesion_quality_bad_checkbox.toggled.connect(self._on_lesion_quality_bad_toggled)
        lesion_quality_row.addWidget(self.lesion_quality_bad_checkbox)

        self.lesion_quality_detail_container = qt.QWidget()
        lesion_quality_detail_layout = qt.QHBoxLayout(self.lesion_quality_detail_container)
        lesion_quality_detail_layout.setContentsMargins(0, 0, 0, 0)
        lesion_quality_detail_layout.addWidget(qt.QLabel("If bad:"))
        self.lesion_adjusted_radio = qt.QRadioButton("Adjusted")
        self.lesion_ignored_radio = qt.QRadioButton("Ignored")
        self.lesion_adjust_later_radio = qt.QRadioButton("Adjust later")
        self.lesion_not_visible_radio = qt.QRadioButton("Not visible")
        self.lesion_quality_detail_group = qt.QButtonGroup(self.dialog)
        self.lesion_quality_detail_group.setExclusive(True)
        self.lesion_quality_detail_group.addButton(self.lesion_adjusted_radio)
        self.lesion_quality_detail_group.addButton(self.lesion_ignored_radio)
        self.lesion_quality_detail_group.addButton(self.lesion_adjust_later_radio)
        self.lesion_quality_detail_group.addButton(self.lesion_not_visible_radio)
        lesion_quality_detail_layout.addWidget(self.lesion_adjusted_radio)
        lesion_quality_detail_layout.addWidget(self.lesion_ignored_radio)
        lesion_quality_detail_layout.addWidget(self.lesion_adjust_later_radio)
        lesion_quality_detail_layout.addWidget(self.lesion_not_visible_radio)
        lesion_quality_detail_layout.addStretch(1)
        lesion_quality_row.addWidget(self.lesion_quality_detail_container, 1)
        review_layout.addLayout(lesion_quality_row)

        atypical_row = qt.QHBoxLayout()
        self.atypical_tumor_checkbox = qt.QCheckBox("Atypical Tumor")
        self.atypical_tumor_checkbox.toggled.connect(self._on_atypical_tumor_toggled)
        atypical_row.addWidget(self.atypical_tumor_checkbox)

        self.atypical_tumor_detail_container = qt.QWidget()
        atypical_detail_layout = qt.QHBoxLayout(self.atypical_tumor_detail_container)
        atypical_detail_layout.setContentsMargins(0, 0, 0, 0)
        atypical_detail_layout.addWidget(qt.QLabel("If atypical:"))
        self.atypical_tumor_net_radio = qt.QRadioButton("NET")
        self.atypical_tumor_ipmn_radio = qt.QRadioButton("IPMN")
        self.atypical_tumor_other_radio = qt.QRadioButton("Other")
        self.atypical_tumor_type_group = qt.QButtonGroup(self.dialog)
        self.atypical_tumor_type_group.setExclusive(True)
        self.atypical_tumor_type_group.addButton(self.atypical_tumor_net_radio)
        self.atypical_tumor_type_group.addButton(self.atypical_tumor_ipmn_radio)
        self.atypical_tumor_type_group.addButton(self.atypical_tumor_other_radio)
        self.atypical_tumor_net_radio.toggled.connect(self._on_atypical_tumor_subtype_changed)
        self.atypical_tumor_ipmn_radio.toggled.connect(self._on_atypical_tumor_subtype_changed)
        self.atypical_tumor_other_radio.toggled.connect(self._on_atypical_tumor_subtype_changed)
        atypical_detail_layout.addWidget(self.atypical_tumor_net_radio)
        atypical_detail_layout.addWidget(self.atypical_tumor_ipmn_radio)
        atypical_detail_layout.addWidget(self.atypical_tumor_other_radio)
        atypical_detail_layout.addWidget(qt.QLabel("Other name:"))
        self.atypical_tumor_other_name_edit = qt.QLineEdit()
        self.atypical_tumor_other_name_edit.setPlaceholderText("Enter tumor type")
        self.atypical_tumor_other_name_edit.setFixedWidth(180)
        atypical_detail_layout.addWidget(self.atypical_tumor_other_name_edit)
        atypical_detail_layout.addStretch(1)
        atypical_row.addWidget(self.atypical_tumor_detail_container, 1)
        review_layout.addLayout(atypical_row)

        comments_label = qt.QLabel("Comments:")
        review_layout.addWidget(comments_label)
        self.comments_text_edit = qt.QPlainTextEdit()
        if hasattr(self.comments_text_edit, "setPlaceholderText"):
            self.comments_text_edit.setPlaceholderText("Optional comments for this case")
        if hasattr(self.comments_text_edit, "setMaximumBlockCount"):
            self.comments_text_edit.setMaximumBlockCount(1000)
        self.comments_text_edit.setFixedHeight(80)
        review_layout.addWidget(self.comments_text_edit)

        layout.addWidget(review_group)

        button_row = qt.QHBoxLayout()
        btn_prev = qt.QPushButton("Previous")
        btn_save = qt.QPushButton("Save")
        btn_next_save = qt.QPushButton("Save + Next")
        btn_next_no_save = qt.QPushButton("Next (No Save)")
        btn_reload = qt.QPushButton("Reload Current")
        btn_export_metadata = qt.QPushButton("Export metadata.xlsx updates")
        btn_export_metadata.setToolTip("Batch-write all saved per-case review metadata sidecars back into metadata.xlsx.")

        btn_prev.clicked.connect(self.previous_case)
        btn_save.clicked.connect(self.save_current_case)
        btn_next_save.clicked.connect(self.save_and_next)
        btn_next_no_save.clicked.connect(self.next_without_save)
        btn_reload.clicked.connect(self.reload_current)
        btn_export_metadata.clicked.connect(self._on_export_review_metadata_clicked)

        button_row.addWidget(btn_prev)
        button_row.addWidget(btn_save)
        button_row.addWidget(btn_next_save)
        button_row.addWidget(btn_next_no_save)
        button_row.addWidget(btn_reload)
        button_row.addWidget(btn_export_metadata)
        layout.addLayout(button_row)

        hint = qt.QLabel(
            "Suggested: open Segment Editor, edit segments 'pancreas', 'pancreatic_duct', "
            "'common_bile_duct', and 'pancreatic_lesion', "
            "then click Save + Next. Use 'Export metadata.xlsx updates' when you want to batch-write "
            "review flags back to metadata.xlsx."
        )
        hint.wordWrap = True
        layout.addWidget(hint)

        self._reset_review_ui()
        self._update_metadata_export_reminder()
        self.dialog.show()

    def _clear_button_group_selection(self, group):
        if group is None:
            return
        group.setExclusive(False)
        for button in group.buttons():
            button.setChecked(False)
        group.setExclusive(True)

    def _reset_review_ui(self):
        if self.image_quality_bad_checkbox is not None:
            self.image_quality_bad_checkbox.setChecked(False)
        if self.pancreas_quality_bad_checkbox is not None:
            self.pancreas_quality_bad_checkbox.setChecked(False)
        if self.pancreas_quality_detail_group is not None:
            self._clear_button_group_selection(self.pancreas_quality_detail_group)
        if self.lesion_type_group is not None:
            self._clear_button_group_selection(self.lesion_type_group)
        if self.lesion_quality_bad_checkbox is not None:
            self.lesion_quality_bad_checkbox.setChecked(False)
        if self.lesion_quality_detail_group is not None:
            self._clear_button_group_selection(self.lesion_quality_detail_group)
        if self.atypical_tumor_checkbox is not None:
            self.atypical_tumor_checkbox.setChecked(False)
        if self.atypical_tumor_type_group is not None:
            self._clear_button_group_selection(self.atypical_tumor_type_group)
        if self.atypical_tumor_other_name_edit is not None:
            self.atypical_tumor_other_name_edit.setText("")
        if self.comments_text_edit is not None:
            self.comments_text_edit.setPlainText("")
        self._on_pancreas_quality_bad_toggled(False)
        self._on_lesion_quality_bad_toggled(False)
        self._on_atypical_tumor_toggled(False)
        self._on_atypical_tumor_subtype_changed(False)

    def _on_pancreas_quality_bad_toggled(self, checked):
        if self.pancreas_quality_detail_container is not None:
            self.pancreas_quality_detail_container.setEnabled(bool(checked))
        if not checked and self.pancreas_quality_detail_group is not None:
            self._clear_button_group_selection(self.pancreas_quality_detail_group)

    def _on_lesion_quality_bad_toggled(self, checked):
        if self.lesion_quality_detail_container is not None:
            self.lesion_quality_detail_container.setEnabled(bool(checked))
        if not checked and self.lesion_quality_detail_group is not None:
            self._clear_button_group_selection(self.lesion_quality_detail_group)

    def _on_atypical_tumor_toggled(self, checked):
        enabled = bool(checked)
        if self.atypical_tumor_detail_container is not None:
            self.atypical_tumor_detail_container.setEnabled(enabled)
        if not enabled:
            if self.atypical_tumor_type_group is not None:
                self._clear_button_group_selection(self.atypical_tumor_type_group)
            if self.atypical_tumor_other_name_edit is not None:
                self.atypical_tumor_other_name_edit.setText("")
        self._on_atypical_tumor_subtype_changed(False)

    def _on_atypical_tumor_subtype_changed(self, _checked):
        atypical_enabled = bool(self.atypical_tumor_checkbox.isChecked()) if self.atypical_tumor_checkbox else False
        other_selected = bool(self.atypical_tumor_other_radio.isChecked()) if self.atypical_tumor_other_radio else False
        allow_other_text = atypical_enabled and other_selected
        if self.atypical_tumor_other_name_edit is not None:
            self.atypical_tumor_other_name_edit.setEnabled(allow_other_text)
            if not allow_other_text:
                self.atypical_tumor_other_name_edit.setText("")

    def _read_text_widget_value(self, widget):
        if widget is None:
            return ""
        for attr_name in ("text", "toPlainText"):
            if not hasattr(widget, attr_name):
                continue
            value = getattr(widget, attr_name)
            if callable(value):
                value = value()
            return _safe_stripped(value)
        return ""

    def _collect_review_metadata_values(self):
        pancreas_quality_bad = (
            bool(self.pancreas_quality_bad_checkbox.isChecked()) if self.pancreas_quality_bad_checkbox else False
        )
        lesion_quality_bad = (
            bool(self.lesion_quality_bad_checkbox.isChecked()) if self.lesion_quality_bad_checkbox else False
        )
        atypical_tumor = bool(self.atypical_tumor_checkbox.isChecked()) if self.atypical_tumor_checkbox else False
        atypical_other = atypical_tumor and bool(self.atypical_tumor_other_radio.isChecked()) if self.atypical_tumor_other_radio else False
        values = {
            "image_quality_bad": bool(self.image_quality_bad_checkbox.isChecked()) if self.image_quality_bad_checkbox else False,
            "pancreas_quality_bad": pancreas_quality_bad,
            "pancreas_adjusted": pancreas_quality_bad
            and bool(self.pancreas_adjusted_radio.isChecked()) if self.pancreas_adjusted_radio else False,
            "pancreas_adjust_later": pancreas_quality_bad
            and bool(self.pancreas_adjust_later_radio.isChecked()) if self.pancreas_adjust_later_radio else False,
            "lesion_type_tumor": bool(self.lesion_type_tumor_radio.isChecked()) if self.lesion_type_tumor_radio else False,
            "lesion_type_cyste": bool(self.lesion_type_cyste_radio.isChecked()) if self.lesion_type_cyste_radio else False,
            "lesion_type_tumor_cyste": bool(self.lesion_type_tumor_cyste_radio.isChecked()) if self.lesion_type_tumor_cyste_radio else False,
            "lesion_type_multiple_tumors": bool(self.lesion_type_multiple_tumors_radio.isChecked()) if self.lesion_type_multiple_tumors_radio else False,
            "lesion_quality_bad": lesion_quality_bad,
            "lesion_adjusted": lesion_quality_bad and bool(self.lesion_adjusted_radio.isChecked()) if self.lesion_adjusted_radio else False,
            "lesion_ignored": lesion_quality_bad and bool(self.lesion_ignored_radio.isChecked()) if self.lesion_ignored_radio else False,
            "lesion_adjust_later": lesion_quality_bad
            and bool(self.lesion_adjust_later_radio.isChecked()) if self.lesion_adjust_later_radio else False,
            "lesion_not_visible": lesion_quality_bad
            and bool(self.lesion_not_visible_radio.isChecked()) if self.lesion_not_visible_radio else False,
            "atypical_tumor": atypical_tumor,
            "atypical_tumor_net": atypical_tumor
            and bool(self.atypical_tumor_net_radio.isChecked()) if self.atypical_tumor_net_radio else False,
            "atypical_tumor_ipmn": atypical_tumor
            and bool(self.atypical_tumor_ipmn_radio.isChecked()) if self.atypical_tumor_ipmn_radio else False,
            "atypical_tumor_other": atypical_other,
            "atypical_tumor_other_name": self._read_text_widget_value(self.atypical_tumor_other_name_edit)
            if (atypical_other and self.atypical_tumor_other_name_edit)
            else "",
            "comments": self._read_text_widget_value(self.comments_text_edit),
        }
        return values

    def _populate_review_ui_from_values(self, values):
        self._reset_review_ui()
        if not values:
            return

        if self.image_quality_bad_checkbox is not None:
            self.image_quality_bad_checkbox.setChecked(bool(values.get("image_quality_bad", False)))

        pancreas_quality_bad = bool(values.get("pancreas_quality_bad", False))
        if self.pancreas_quality_bad_checkbox is not None:
            self.pancreas_quality_bad_checkbox.setChecked(pancreas_quality_bad)
        if pancreas_quality_bad:
            if values.get("pancreas_adjusted", False) and self.pancreas_adjusted_radio is not None:
                self.pancreas_adjusted_radio.setChecked(True)
            elif values.get("pancreas_adjust_later", False) and self.pancreas_adjust_later_radio is not None:
                self.pancreas_adjust_later_radio.setChecked(True)

        if values.get("lesion_type_tumor", False) and self.lesion_type_tumor_radio is not None:
            self.lesion_type_tumor_radio.setChecked(True)
        elif values.get("lesion_type_cyste", False) and self.lesion_type_cyste_radio is not None:
            self.lesion_type_cyste_radio.setChecked(True)
        elif values.get("lesion_type_tumor_cyste", False) and self.lesion_type_tumor_cyste_radio is not None:
            self.lesion_type_tumor_cyste_radio.setChecked(True)
        elif values.get("lesion_type_multiple_tumors", False) and self.lesion_type_multiple_tumors_radio is not None:
            self.lesion_type_multiple_tumors_radio.setChecked(True)

        lesion_quality_bad = bool(values.get("lesion_quality_bad", False))
        if self.lesion_quality_bad_checkbox is not None:
            self.lesion_quality_bad_checkbox.setChecked(lesion_quality_bad)
        if lesion_quality_bad:
            if values.get("lesion_adjusted", False) and self.lesion_adjusted_radio is not None:
                self.lesion_adjusted_radio.setChecked(True)
            elif values.get("lesion_ignored", False) and self.lesion_ignored_radio is not None:
                self.lesion_ignored_radio.setChecked(True)
            elif values.get("lesion_adjust_later", False) and self.lesion_adjust_later_radio is not None:
                self.lesion_adjust_later_radio.setChecked(True)
            elif values.get("lesion_not_visible", False) and self.lesion_not_visible_radio is not None:
                self.lesion_not_visible_radio.setChecked(True)

        atypical_tumor = bool(values.get("atypical_tumor", False))
        if self.atypical_tumor_checkbox is not None:
            self.atypical_tumor_checkbox.setChecked(atypical_tumor)
        if atypical_tumor:
            if values.get("atypical_tumor_net", False) and self.atypical_tumor_net_radio is not None:
                self.atypical_tumor_net_radio.setChecked(True)
            elif values.get("atypical_tumor_ipmn", False) and self.atypical_tumor_ipmn_radio is not None:
                self.atypical_tumor_ipmn_radio.setChecked(True)
            elif values.get("atypical_tumor_other", False) and self.atypical_tumor_other_radio is not None:
                self.atypical_tumor_other_radio.setChecked(True)
                if self.atypical_tumor_other_name_edit is not None:
                    self.atypical_tumor_other_name_edit.setText(
                        _safe_stripped(values.get("atypical_tumor_other_name", ""))
                    )

        if self.comments_text_edit is not None:
            self.comments_text_edit.setPlainText(_safe_stripped(values.get("comments", "")))

    def _review_metadata_sidecar_path(self, case_id: str):
        return self._case_output_dir(case_id) / REVIEW_METADATA_FILENAME

    def _read_review_metadata_sidecar_payload_for_case(self, case_id: str):
        sidecar_path = self._review_metadata_sidecar_path(case_id)
        if not self._is_nonempty_file(sidecar_path):
            return None

        payload = json.loads(sidecar_path.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            raise RuntimeError(f"Review metadata sidecar has invalid format for '{case_id}'.")
        payload_case_id = _safe_stripped(payload.get("case_id"))
        if payload_case_id and payload_case_id != case_id:
            raise RuntimeError(f"Review metadata sidecar case_id mismatch for '{case_id}'.")
        return payload

    def _read_review_metadata_from_workbook_for_case(self, case_id: str):
        try:
            import openpyxl  # type: ignore
        except Exception:
            return None

        wb = openpyxl.load_workbook(str(self.metadata_path), data_only=True, read_only=True)
        try:
            ws = wb["PanTS_metadata"] if "PanTS_metadata" in wb.sheetnames else wb[wb.sheetnames[0]]

            header = {}
            header_cells = next(ws.iter_rows(min_row=1, max_row=1))
            for col_idx, cell in enumerate(header_cells, start=1):
                header[_safe_stripped(cell.value)] = col_idx
            id_col = header.get("PanTS ID")
            if not id_col:
                return None

            target_row = None
            for row in ws.iter_rows(min_row=2, values_only=True):
                if len(row) < id_col:
                    continue
                if _safe_stripped(row[id_col - 1]) == case_id:
                    target_row = row
                    break
            if target_row is None:
                return None

            values = _default_review_metadata_values()
            for key, col_name in REANNOTATION_METADATA_COLUMNS:
                col_idx = header.get(col_name)
                if not col_idx or len(target_row) < col_idx:
                    continue
                cell_value = target_row[col_idx - 1]
                values[key] = (
                    _safe_stripped(cell_value) if key in REANNOTATION_TEXT_KEYS else _truthy_tumor_flag(cell_value)
                )
            predicted_phase_col_idx = header.get(METADATA_COL_MISMATCH_PREDICTED_PHASE)
            if predicted_phase_col_idx and len(target_row) >= predicted_phase_col_idx:
                values["_predicted_phase"] = _safe_stripped(target_row[predicted_phase_col_idx - 1])
            else:
                values["_predicted_phase"] = ""
            return values
        finally:
            if hasattr(wb, "close"):
                wb.close()

    def _read_review_metadata_sidecar_for_case(self, case_id: str):
        payload = self._read_review_metadata_sidecar_payload_for_case(case_id)
        if payload is None:
            return None

        if isinstance(payload.get("review_metadata"), dict):
            raw_values = payload["review_metadata"]
        else:
            raw_values = payload
        return _normalized_review_metadata_values(raw_values)

    def _write_review_metadata_sidecar_for_case(self, case_id: str, values):
        case_out = self._case_output_dir(case_id)
        case_out.mkdir(parents=True, exist_ok=True)
        sidecar_path = self._review_metadata_sidecar_path(case_id)
        sidecar_tmp = case_out / f"{REVIEW_METADATA_FILENAME}.tmp"
        updated_at_utc = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
        existing_payload = None
        try:
            existing_payload = self._read_review_metadata_sidecar_payload_for_case(case_id)
        except Exception:
            existing_payload = None
        payload = {
            "case_id": case_id,
            "format_version": 1,
            "updated_at_utc": updated_at_utc,
            "review_metadata": _normalized_review_metadata_values(values),
        }
        exported_at_utc = _safe_stripped(existing_payload.get("exported_to_metadata_xlsx_at_utc")) if existing_payload else ""
        if exported_at_utc:
            payload["exported_to_metadata_xlsx_at_utc"] = exported_at_utc
        sidecar_tmp.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        sidecar_tmp.replace(sidecar_path)

    def _mark_review_metadata_sidecar_exported(self, case_id: str, exported_at_utc: str):
        payload = self._read_review_metadata_sidecar_payload_for_case(case_id)
        if payload is None:
            return

        case_out = self._case_output_dir(case_id)
        sidecar_path = self._review_metadata_sidecar_path(case_id)
        sidecar_tmp = case_out / f"{REVIEW_METADATA_FILENAME}.tmp"
        payload["exported_to_metadata_xlsx_at_utc"] = exported_at_utc
        sidecar_tmp.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        sidecar_tmp.replace(sidecar_path)

    def _review_metadata_sidecar_needs_export(self, case_id: str):
        payload = self._read_review_metadata_sidecar_payload_for_case(case_id)
        if payload is None:
            return False

        updated_at_utc = _safe_stripped(payload.get("updated_at_utc"))
        exported_at_utc = _safe_stripped(payload.get("exported_to_metadata_xlsx_at_utc"))
        if not updated_at_utc:
            return True
        if not exported_at_utc:
            return True
        return exported_at_utc < updated_at_utc

    def _count_review_metadata_sidecars_pending_export(self):
        pending_count = 0
        for case_record in self.case_records:
            case_id = case_record["case_id"]
            try:
                if self._review_metadata_sidecar_needs_export(case_id):
                    pending_count += 1
            except Exception:
                pending_count += 1
        return pending_count

    def _update_metadata_export_reminder(self):
        if self.metadata_export_reminder_label is None:
            return

        pending_count = self._count_review_metadata_sidecars_pending_export()
        if pending_count > 0:
            self.metadata_export_reminder_label.setText(
                f"Reminder: {pending_count} case(s) have review metadata saved locally but not exported to "
                "metadata.xlsx. Click 'Export metadata.xlsx updates' before quitting."
            )
            self.metadata_export_reminder_label.setStyleSheet("color: #b00020; font-weight: 600;")
        else:
            self.metadata_export_reminder_label.setText("")
            self.metadata_export_reminder_label.setStyleSheet("")

    def _read_review_metadata_for_case(self, case_id: str):
        workbook_values = self._read_review_metadata_from_workbook_for_case(case_id)
        sidecar_values = self._read_review_metadata_sidecar_for_case(case_id)
        if workbook_values is None and sidecar_values is None:
            return None

        merged_values = dict(workbook_values) if workbook_values is not None else _default_review_metadata_values()
        merged_values.setdefault("_predicted_phase", "")
        if sidecar_values is not None:
            merged_values.update(sidecar_values)
        return merged_values

    def export_review_metadata_to_workbook(self):
        try:
            import openpyxl  # type: ignore
        except Exception as exc:
            raise RuntimeError(
                "Exporting metadata.xlsx requires openpyxl in Slicer Python. "
                "Install with: slicer.util.pip_install('openpyxl')"
            ) from exc

        wb = openpyxl.load_workbook(str(self.metadata_path))
        try:
            ws = wb["PanTS_metadata"] if "PanTS_metadata" in wb.sheetnames else wb[wb.sheetnames[0]]

            header_map = {}
            max_col = max(1, ws.max_column)
            for col_idx in range(1, max_col + 1):
                header_name = _safe_stripped(ws.cell(row=1, column=col_idx).value)
                if header_name:
                    header_map[header_name] = col_idx

            id_col = header_map.get("PanTS ID")
            if not id_col:
                raise RuntimeError("metadata.xlsx is missing required column 'PanTS ID'.")

            for _, col_name in REANNOTATION_METADATA_COLUMNS:
                if col_name not in header_map:
                    max_col += 1
                    ws.cell(row=1, column=max_col, value=col_name)
                    header_map[col_name] = max_col

            row_by_case_id = {}
            for row_idx in range(2, ws.max_row + 1):
                row_case_id = _safe_stripped(ws.cell(row=row_idx, column=id_col).value)
                if row_case_id:
                    row_by_case_id[row_case_id] = row_idx

            exported_case_count = 0
            exported_case_ids = []
            missing_case_ids = []
            for case_record in self.case_records:
                case_id = case_record["case_id"]
                values = self._read_review_metadata_sidecar_for_case(case_id)
                if values is None:
                    continue

                target_row_idx = row_by_case_id.get(case_id)
                if target_row_idx is None:
                    missing_case_ids.append(case_id)
                    continue

                for key, col_name in REANNOTATION_METADATA_COLUMNS:
                    cell = ws.cell(row=target_row_idx, column=header_map[col_name])
                    if key in REANNOTATION_TEXT_KEYS:
                        text_value = _safe_stripped(values.get(key, ""))
                        cell.value = text_value if text_value else ""
                    else:
                        cell.value = 1 if bool(values.get(key, False)) else 0
                exported_case_count += 1
                exported_case_ids.append(case_id)

            if exported_case_count > 0:
                wb.save(str(self.metadata_path))
                exported_at_utc = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
                for case_id in exported_case_ids:
                    self._mark_review_metadata_sidecar_exported(case_id, exported_at_utc)

            message = f"Exported metadata sidecars for {exported_case_count} case(s) to metadata.xlsx."
            if missing_case_ids:
                message += f" Missing in workbook: {', '.join(missing_case_ids[:10])}"
                if len(missing_case_ids) > 10:
                    message += f" (+{len(missing_case_ids) - 10} more)"
            if exported_case_count == 0 and not missing_case_ids:
                message = "No review metadata sidecars found to export."
            self._set_status(message)
            self._update_metadata_export_reminder()
            if exported_case_count > 0 or missing_case_ids:
                slicer.util.infoDisplay(message)
        finally:
            if hasattr(wb, "close"):
                wb.close()

    def _on_export_review_metadata_clicked(self):
        try:
            self.export_review_metadata_to_workbook()
        except Exception as exc:
            self._set_status(f"metadata.xlsx export failed: {exc}")
            print(traceback.format_exc())
            slicer.util.errorDisplay(f"metadata.xlsx export failed\n\n{exc}")

    def _load_review_metadata_into_ui(self, case_id: str):
        try:
            values = self._read_review_metadata_for_case(case_id)
        except Exception as exc:
            self._set_status(f"Warning: could not read existing metadata flags ({exc})")
            values = None
        predicted_phase_text = ""
        if values:
            predicted_phase_text = _safe_stripped(values.get("_predicted_phase", ""))
        if self.predicted_phase_label is not None:
            self.predicted_phase_label.setText(
                f"Predicted phase (metadata `{METADATA_COL_MISMATCH_PREDICTED_PHASE}`): "
                f"{predicted_phase_text if predicted_phase_text else '(missing)'}"
            )
        self._populate_review_ui_from_values(values)

    def _clear_loaded_nodes(self):
        for node_id in self.loaded_node_ids:
            node = slicer.mrmlScene.GetNodeByID(node_id)
            if node is not None:
                slicer.mrmlScene.RemoveNode(node)
        self.loaded_node_ids = []
        self.current_volume_node = None
        self.current_seg_node = None
        self.current_segment_ids = {}

    def _append_loaded_node(self, node):
        if node is not None:
            self.loaded_node_ids.append(node.GetID())

    def _add_empty_segment(self, segmentation_node, name, color):
        segment_id = segmentation_node.GetSegmentation().AddEmptySegment(name)
        segment = segmentation_node.GetSegmentation().GetSegment(segment_id)
        if segment is not None:
            segment.SetName(name)
            segment.SetColor(color[0], color[1], color[2])
        return segment_id

    def _import_label_as_segment(self, segmentation_node, label_path: Path, segment_name: str, color):
        if not label_path.exists():
            return self._add_empty_segment(segmentation_node, segment_name, color), False

        success, label_node = slicer.util.loadLabelVolume(str(label_path), returnNode=True)
        if not success:
            return self._add_empty_segment(segmentation_node, segment_name, color), False

        before = segmentation_node.GetSegmentation().GetNumberOfSegments()
        imported = slicer.modules.segmentations.logic().ImportLabelmapToSegmentationNode(label_node, segmentation_node)
        slicer.mrmlScene.RemoveNode(label_node)
        if not imported:
            return self._add_empty_segment(segmentation_node, segment_name, color), False

        after = segmentation_node.GetSegmentation().GetNumberOfSegments()
        if after <= before:
            return self._add_empty_segment(segmentation_node, segment_name, color), False

        seg_id = segmentation_node.GetSegmentation().GetNthSegmentID(after - 1)
        segment = segmentation_node.GetSegmentation().GetSegment(seg_id)
        segment.SetName(segment_name)
        segment.SetColor(color[0], color[1], color[2])
        return seg_id, True

    def _set_status(self, text):
        if self.status_label is not None:
            self.status_label.setText(text)
        print(text)

    def _case_output_dir(self, case_id: str):
        return self.output_root / case_id

    def _is_nonempty_file(self, path: Path):
        try:
            return path.exists() and path.is_file() and path.stat().st_size > 0
        except OSError:
            return False

    def _has_review_completion_marker(self, case_id: str):
        case_out = self._case_output_dir(case_id)
        marker_path = case_out / REVIEW_COMPLETION_FILENAME
        if not self._is_nonempty_file(marker_path):
            return False

        try:
            marker_payload = json.loads(marker_path.read_text(encoding="utf-8"))
            marker_case_id = _safe_stripped(marker_payload.get("case_id"))
            if marker_case_id and marker_case_id != case_id:
                return False
        except Exception:
            return False
        return True

    def _has_legacy_complete_outputs(self, case_id: str):
        case_out = self._case_output_dir(case_id)
        seg_path = case_out / "reannotation.seg.nrrd"
        pancreas_out = case_out / "segmentations" / "pancreas.nii.gz"
        lesion_out = case_out / "segmentations" / "pancreatic_lesion.nii.gz"
        return (
            self._is_nonempty_file(seg_path)
            and self._is_nonempty_file(pancreas_out)
            and self._is_nonempty_file(lesion_out)
        )

    def _is_case_reviewed(self, case_record):
        case_id = case_record["case_id"]
        return self._has_review_completion_marker(case_id) or self._has_legacy_complete_outputs(case_id)

    def _is_skip_reviewed_enabled(self):
        return bool(self.skip_reviewed_checkbox and self.skip_reviewed_checkbox.isChecked())

    def _find_case_index(self, start_index: int, step: int, skip_reviewed: bool):
        if step not in (-1, 1):
            raise ValueError("step must be -1 or 1")
        idx = start_index + step
        while 0 <= idx < len(self.case_records):
            if not skip_reviewed or not self._is_case_reviewed(self.case_records[idx]):
                return idx
            idx += step
        return None

    def _write_review_completion_marker(self, case_id: str, saved_reannotation_seg_nrrd: bool):
        case_out = self._case_output_dir(case_id)
        case_out.mkdir(parents=True, exist_ok=True)
        marker_path = case_out / REVIEW_COMPLETION_FILENAME
        marker_tmp = case_out / f"{REVIEW_COMPLETION_FILENAME}.tmp"
        completed_at_utc = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
        marker_payload = {
            "case_id": case_id,
            "completed_at_utc": completed_at_utc,
            "format_version": 2,
            "saved_reannotation_seg_nrrd": bool(saved_reannotation_seg_nrrd),
        }
        marker_tmp.write_text(json.dumps(marker_payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        marker_tmp.replace(marker_path)

    def _activate_case_nodes_in_editors(self, volume_node, seg_node):
        if volume_node is None or seg_node is None:
            return
        if slicer.mrmlScene.GetNodeByID(volume_node.GetID()) is None:
            return
        if slicer.mrmlScene.GetNodeByID(seg_node.GetID()) is None:
            return

        # Keep scene selection in sync so all modules see the active case volume.
        app_logic = slicer.app.applicationLogic()
        if app_logic is not None:
            selection_node = app_logic.GetSelectionNode()
            if selection_node is not None and hasattr(selection_node, "SetReferenceActiveVolumeID"):
                selection_node.SetReferenceActiveVolumeID(volume_node.GetID())
            app_logic.PropagateVolumeSelection(0)

        # Ensure Segment Editor is bound to the newly loaded segmentation and source volume.
        segment_editor_node = slicer.mrmlScene.GetFirstNodeByClass("vtkMRMLSegmentEditorNode")
        if segment_editor_node is None:
            segment_editor_node = slicer.mrmlScene.AddNewNodeByClass("vtkMRMLSegmentEditorNode")
        if segment_editor_node is not None:
            if hasattr(segment_editor_node, "SetSegmentationNodeID"):
                segment_editor_node.SetSegmentationNodeID(seg_node.GetID())
            if hasattr(segment_editor_node, "SetSourceVolumeNodeID"):
                segment_editor_node.SetSourceVolumeNodeID(volume_node.GetID())
            elif hasattr(segment_editor_node, "SetMasterVolumeNodeID"):
                segment_editor_node.SetMasterVolumeNodeID(volume_node.GetID())

        # Also update visible Segment Editor widget (if open) to avoid manual node click.
        try:
            segment_editor_module = getattr(slicer.modules, "segmenteditor", None)
            if segment_editor_module is not None:
                widget_rep = segment_editor_module.widgetRepresentation()
                widget_self = widget_rep.self() if widget_rep is not None and hasattr(widget_rep, "self") else None
                editor_widget = widget_self.editor if widget_self is not None and hasattr(widget_self, "editor") else None
                if editor_widget is not None:
                    if hasattr(editor_widget, "setSegmentationNode"):
                        editor_widget.setSegmentationNode(seg_node)
                    if hasattr(editor_widget, "setSourceVolumeNode"):
                        editor_widget.setSourceVolumeNode(volume_node)
        except Exception:
            # Non-fatal: selection and segment editor node are already updated above.
            pass

    def load_case(self, index):
        if index < 0 or index >= len(self.case_records):
            return

        self._clear_loaded_nodes()
        self.current_index = index
        self.current_case = self.case_records[index]

        case_id = self.current_case["case_id"]
        ct_path = self.current_case["ct_path"]
        pancreas_path = self.current_case["pancreas_path"]
        pancreatic_duct_path = self.current_case["pancreatic_duct_path"]
        common_bile_duct_path = self.current_case["common_bile_duct_path"]
        lesion_path = self.current_case["lesion_path"]
        self._load_review_metadata_into_ui(case_id)

        ok, volume_node = slicer.util.loadVolume(str(ct_path), returnNode=True)
        if not ok:
            raise RuntimeError(f"Failed to load CT volume: {ct_path}")
        volume_node.SetName(f"{case_id}_CT")
        _apply_ct_abdomen_window(volume_node)
        self.current_volume_node = volume_node
        self._append_loaded_node(volume_node)

        seg_node = slicer.mrmlScene.AddNewNodeByClass("vtkMRMLSegmentationNode", f"{case_id}_Reannotation")
        seg_node.CreateDefaultDisplayNodes()
        seg_node.SetReferenceImageGeometryParameterFromVolumeNode(volume_node)
        self.current_seg_node = seg_node
        self._append_loaded_node(seg_node)

        pancreas_id, pancreas_loaded = self._import_label_as_segment(
            seg_node, pancreas_path, "pancreas", SEGMENT_COLORS["pancreas"]
        )
        pancreatic_duct_id, pancreatic_duct_loaded = self._import_label_as_segment(
            seg_node, pancreatic_duct_path, "pancreatic_duct", SEGMENT_COLORS["pancreatic_duct"]
        )
        common_bile_duct_id, common_bile_duct_loaded = self._import_label_as_segment(
            seg_node,
            common_bile_duct_path,
            "common_bile_duct",
            SEGMENT_COLORS["common_bile_duct"],
        )
        lesion_id, lesion_loaded = self._import_label_as_segment(
            seg_node, lesion_path, "pancreatic_lesion", SEGMENT_COLORS["pancreatic_lesion"]
        )
        self.current_segment_ids = {
            "pancreas": pancreas_id,
            "pancreatic_duct": pancreatic_duct_id,
            "common_bile_duct": common_bile_duct_id,
            "pancreatic_lesion": lesion_id,
        }

        display = seg_node.GetDisplayNode()
        if display is not None:
            display.SetVisibility2DFill(True)
            display.SetVisibility2DOutline(True)
            display.SetOpacity2DFill(0.35)
            display.SetOpacity2DOutline(1.0)
            display.SetSegmentVisibility(pancreas_id, True)
            display.SetSegmentVisibility(pancreatic_duct_id, True)
            display.SetSegmentVisibility(common_bile_duct_id, True)
            display.SetSegmentVisibility(lesion_id, True)

        slicer.util.setSliceViewerLayers(background=volume_node)
        slicer.util.resetSliceViews()
        self._activate_case_nodes_in_editors(volume_node, seg_node)

        # Re-apply once after event processing to handle delayed widget updates (common on Windows).
        qt.QTimer.singleShot(100, lambda v=volume_node, s=seg_node: self._activate_case_nodes_in_editors(v, s))
        reviewed = self._is_case_reviewed(self.current_case)

        if self.case_label is not None:
            self.case_label.setText(
                f"Case {index + 1}/{len(self.case_records)}: {case_id} (split={self.current_case['split']})\n"
                f"Reviewed: {'yes' if reviewed else 'no'}\n"
                f"CT: {ct_path}\n"
                f"Pancreas label loaded: {'yes' if pancreas_loaded else 'no (empty segment created)'}\n"
                f"Pancreatic duct label loaded: {'yes' if pancreatic_duct_loaded else 'no (empty segment created)'}\n"
                f"Common bile duct label loaded: {'yes' if common_bile_duct_loaded else 'no (empty segment created)'}\n"
                f"Tumor label loaded: {'yes' if lesion_loaded else 'no (empty segment created)'}"
            )

        self._set_status("Loaded. Annotate, then click Save + Next.")

    def _export_segment_to_file(self, seg_node, seg_id, ref_volume_node, output_path: Path):
        output_path.parent.mkdir(parents=True, exist_ok=True)
        labelmap_node = slicer.mrmlScene.AddNewNodeByClass("vtkMRMLLabelMapVolumeNode")
        ids = vtk.vtkStringArray()
        ids.InsertNextValue(seg_id)
        ok = slicer.modules.segmentations.logic().ExportSegmentsToLabelmapNode(
            seg_node, ids, labelmap_node, ref_volume_node
        )
        if not ok:
            slicer.mrmlScene.RemoveNode(labelmap_node)
            raise RuntimeError(f"Failed to export segment to labelmap: {output_path}")

        saved = slicer.util.saveNode(labelmap_node, str(output_path))
        slicer.mrmlScene.RemoveNode(labelmap_node)
        if not saved:
            raise RuntimeError(f"Failed to save labelmap: {output_path}")

    def save_current_case(self):
        if self.current_case is None or self.current_seg_node is None or self.current_volume_node is None:
            self._set_status("Nothing loaded to save.")
            return False

        case_id = self.current_case["case_id"]
        case_out = self.output_root / case_id
        seg_out = case_out / "segmentations"
        seg_out.mkdir(parents=True, exist_ok=True)
        save_reannotation_seg_nrrd = not (
            self.skip_nrrd_save_checkbox is not None and self.skip_nrrd_save_checkbox.isChecked()
        )
        timing_steps = []

        def _time_step(step_name, func):
            started_at = perf_counter()
            result = func()
            timing_steps.append((step_name, perf_counter() - started_at))
            return result

        try:
            if save_reannotation_seg_nrrd:
                seg_saved = _time_step(
                    "save reannotation.seg.nrrd",
                    lambda: slicer.util.saveNode(self.current_seg_node, str(case_out / "reannotation.seg.nrrd")),
                )
                if not seg_saved:
                    raise RuntimeError("Failed to save full segmentation node.")

            segmentation = self.current_seg_node.GetSegmentation()

            pancreas_id = self.current_segment_ids.get("pancreas")
            if pancreas_id and segmentation.GetSegment(pancreas_id) is not None:
                _time_step(
                    "export pancreas.nii.gz",
                    lambda: self._export_segment_to_file(
                        self.current_seg_node,
                        pancreas_id,
                        self.current_volume_node,
                        seg_out / "pancreas.nii.gz",
                    ),
                )

            pancreatic_duct_id = self.current_segment_ids.get("pancreatic_duct")
            if pancreatic_duct_id and segmentation.GetSegment(pancreatic_duct_id) is not None:
                _time_step(
                    "export pancreatic_duct.nii.gz",
                    lambda: self._export_segment_to_file(
                        self.current_seg_node,
                        pancreatic_duct_id,
                        self.current_volume_node,
                        seg_out / "pancreatic_duct.nii.gz",
                    ),
                )

            common_bile_duct_id = self.current_segment_ids.get("common_bile_duct")
            if common_bile_duct_id and segmentation.GetSegment(common_bile_duct_id) is not None:
                _time_step(
                    "export common_bile_duct.nii.gz",
                    lambda: self._export_segment_to_file(
                        self.current_seg_node,
                        common_bile_duct_id,
                        self.current_volume_node,
                        seg_out / "common_bile_duct.nii.gz",
                    ),
                )

            lesion_id = self.current_segment_ids.get("pancreatic_lesion")
            if lesion_id and segmentation.GetSegment(lesion_id) is not None:
                _time_step(
                    "export pancreatic_lesion.nii.gz",
                    lambda: self._export_segment_to_file(
                        self.current_seg_node,
                        lesion_id,
                        self.current_volume_node,
                        seg_out / "pancreatic_lesion.nii.gz",
                    ),
                )

            review_values = self._collect_review_metadata_values()
            _time_step(
                "write review metadata sidecar",
                lambda: self._write_review_metadata_sidecar_for_case(case_id, review_values),
            )
            _time_step(
                "write review marker",
                lambda: self._write_review_completion_marker(case_id, save_reannotation_seg_nrrd),
            )

            total_elapsed = sum(duration for _, duration in timing_steps)
            timing_summary = ", ".join(f"{name}: {duration:.2f}s" for name, duration in timing_steps)
            print(f"Save timing for {case_id}: total {total_elapsed:.2f}s | {timing_summary}")
            self._update_metadata_export_reminder()

            if save_reannotation_seg_nrrd:
                self._set_status(f"Saved reannotation in {total_elapsed:.2f}s: {case_out}")
            else:
                self._set_status(
                    f"Saved reannotation exports without full .seg.nrrd in {total_elapsed:.2f}s: {case_out}"
                )
            return True
        except Exception as exc:
            self._set_status(f"Save failed: {exc}")
            print(traceback.format_exc())
            slicer.util.errorDisplay(f"Save failed for {case_id}\n\n{exc}")
            return False

    def save_and_next(self):
        if self.save_current_case():
            self._goto_next_case()

    def next_without_save(self):
        self._goto_next_case()

    def _goto_next_case(self):
        next_index = self._find_case_index(self.current_index, 1, self._is_skip_reviewed_enabled())
        if next_index is None:
            if self._is_skip_reviewed_enabled():
                self._set_status("No more unreviewed tumor-positive cases.")
                slicer.util.infoDisplay("No more unreviewed tumor-positive cases.")
            else:
                self._set_status("Finished all tumor-positive cases.")
                slicer.util.infoDisplay("Finished all tumor-positive cases.")
            return
        self.load_case(next_index)

    def previous_case(self):
        prev_index = self._find_case_index(self.current_index, -1, self._is_skip_reviewed_enabled())
        if prev_index is None:
            if self._is_skip_reviewed_enabled():
                self._set_status("No previous unreviewed tumor-positive cases.")
            else:
                self._set_status("Already at first case.")
            return
        self.load_case(prev_index)

    def reload_current(self):
        if self.current_index >= 0:
            self.load_case(self.current_index)


def start_pants_reannotation_navigator():
    dataset_root_str = qt.QFileDialog.getExistingDirectory(
        slicer.util.mainWindow(),
        "Select PanTS dataset root (contains metadata.xlsx, ImageTr/ImageTe/LabelTr/LabelTe)",
        "",
    )
    if not dataset_root_str:
        print("PanTS navigator canceled: dataset root not selected.")
        return

    dataset_root = Path(dataset_root_str)
    default_output = dataset_root / "ReannotatedLabel"
    output_root_str = qt.QFileDialog.getExistingDirectory(
        slicer.util.mainWindow(),
        "Select output root for reannotations (Cancel = use default ReannotatedLabel)",
        str(default_output),
    )
    output_root = Path(output_root_str) if output_root_str else default_output

    navigator = PanTSReannotationNavigator(dataset_root=dataset_root, output_root=output_root)
    navigator.initialize()
    slicer.modules.pants_reannotation_navigator = navigator
    print(
        "PanTS reannotation navigator started.\n"
        "The navigator object is available as: slicer.modules.pants_reannotation_navigator"
    )


start_pants_reannotation_navigator()
